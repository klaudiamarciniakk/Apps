﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BuildPlace : MonoBehaviour {

	public GameObject towerPrefab;

	void OnMouseUpAsButton() {
		// TODO build stuff...
		GameObject g = (GameObject)Instantiate(towerPrefab);
		g.transform.position = transform.position + Vector3.up;
	}
}
